$(document).ready(function(){
	$(".dropdown-trigger").dropdown({hover: true});
	$('.modal').modal();
	$('.modal-trigger').modal();
	//$('.modal-trigger2').modal();
	
	$('#crear').click(function(){
		Swal.fire({
			  title: 'Informacion',
			  text: 'El profesor ha sido añadido',
			  type: 'success',
			  confirmButtonText: 'continuar'
			})
	})
	
	$('#crear2').click(function(){
		Swal.fire({
			  title: 'Informacion',
			  text: 'Los datos personales del profesor se han modificado',
			  type: 'success',
			  confirmButtonText: 'continuar'
			})
	})
	
	$('#eliminar').click(function(e){
		var form = this;
		e.preventDefault();
		swal({
			  title: "¿Esta seguro de que desea eliminar el profesor?",
			  icon: "warning",
			  buttons: true,
			  dangerMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
			    swal("El profesor ha sido eliminado", {
			      icon: "success",
			    });
			  } else {
			    //swal("Your imaginary file is safe!");
			  }
			});
	})

});