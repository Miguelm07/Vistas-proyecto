$(document).ready(function(){
	$(".dropdown-trigger").dropdown({hover: true});
	$('.modal').modal();
	$('.modal-trigger').modal();
	$('select').formSelect();
	$('.datepicker').datepicker();
	//$('.modal-trigger2').modal();
	
	$('#crear').click(function(){
		Swal.fire({
			  title: 'Informacion',
			  text: 'El alumno ha sido añadido',
			  type: 'success',
			  confirmButtonText: 'continuar'
			})
	})
	
	$('#crear2').click(function(){
		Swal.fire({
			  title: 'Informacion',
			  text: 'Los datos personales del alumno se han modificado',
			  type: 'success',
			  confirmButtonText: 'continuar'
			})
	})
	
	$('#eliminar').click(function(e){
		var form = this;
		e.preventDefault();
		swal({
			  title: "¿Esta seguro de que desea dar de baja el alumno?",
			  icon: "warning",
			  buttons: true,
			  dangerMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
			    swal("El alumno ha sido dadod e baja", {
			      icon: "success",
			    });
			  } else {
			    //swal("Your imaginary file is safe!");
			  }
			});
	})

});